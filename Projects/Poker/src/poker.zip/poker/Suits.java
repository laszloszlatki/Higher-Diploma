/*
 * enum to hold all available suits
 * */

package poker;

public enum Suits {
	DIAMONDS,
	CLUBS,
	HEARTS,
	SPADES;	
}
